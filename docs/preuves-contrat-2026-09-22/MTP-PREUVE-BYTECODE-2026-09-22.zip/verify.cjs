const fs=require('fs'),solc=require('solc'),crypto=require('crypto');
const address='0x50626097a780881d3dFf1Ff97579e6dAF965366B';
const save=(name,value)=>fs.writeFileSync(name,JSON.stringify(value,null,2));
async function get(url){const r=await fetch(url,{signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('HTTP '+r.status);return r.json()}
async function rpc(method,params){const r=await fetch('https://mainnet.base.org',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}),signal:AbortSignal.timeout(30000)});if(!r.ok)throw Error('RPC HTTP '+r.status);return r.json()}
const hex=s=>s.replace(/^0x/,'').toLowerCase();
const digest=s=>crypto.createHash('sha256').update(Buffer.from(hex(s),'hex')).digest('hex');
(async()=>{
 const a=await get('https://base.blockscout.com/api/v2/smart-contracts/'+address);save('explorer-current.json',a);
 const sources={[a.file_path]:{content:a.source_code}};for(const s of a.additional_sources)sources[s.file_path]={content:s.source_code};
 const input={language:'Solidity',sources,settings:a.compiler_settings};save('compiler-input.json',input);
 const output=JSON.parse(solc.compile(JSON.stringify(input)));save('compiler-output.json',output);if(output.errors?.some(e=>e.severity==='error'))throw Error(JSON.stringify(output.errors));
 const c=output.contracts[a.file_path][a.name];
 const chain=await rpc('eth_chainId',[]),block=await rpc('eth_blockNumber',[]);if(chain.result!=='0x2105'||!block.result)throw Error('Unexpected chain/block');
 const runtime=await rpc('eth_getCode',[address,block.result]);if(!runtime.result||runtime.result==='0x')throw Error('No runtime');save('rpc-runtime.json',{chain,block,runtime});
 const calls={};for(const [name,data] of Object.entries({totalSupply:'0x18160ddd',decimals:'0x313ce567',owner:'0x8da5cb5b',cap:'0x355274ea'}))calls[name]=await rpc('eth_call',[{to:address,data},block.result]);save('rpc-calls.json',calls);
 const addr=await get('https://base.blockscout.com/api/v2/addresses/'+address);save('address.json',addr);
 const txid=addr.creation_transaction_hash;let tx=null,receipt=null;if(txid){tx=await rpc('eth_getTransactionByHash',[txid]);receipt=await rpc('eth_getTransactionReceipt',[txid]);save('creation-transaction.json',tx);save('creation-receipt.json',receipt)}
 const report={checkedAt:new Date().toISOString(),address,compiler:solc.version(),settings:a.compiler_settings,block:block.result,runtimeBytes:hex(runtime.result).length/2,runtimeFullMatch:hex(c.evm.deployedBytecode.object)===hex(runtime.result),runtimeExplorerMatch:hex(a.deployed_bytecode)===hex(runtime.result),creationExplorerFullMatch:hex(c.evm.bytecode.object)===hex(a.creation_bytecode),creationTransaction:txid,creationDirectMatch:tx?.result?.to===null?hex(c.evm.bytecode.object)===hex(tx.result.input):null,runtimeSHA256:digest(runtime.result),compiledRuntimeSHA256:digest(c.evm.deployedBytecode.object),totalSupplyRaw:calls.totalSupply.result?BigInt(calls.totalSupply.result).toString():null,decimals:calls.decimals.result?Number(BigInt(calls.decimals.result)):null,owner:calls.owner,cap:calls.cap,functions:c.abi.filter(x=>x.type==='function').map(x=>x.name),proxyReported:a.proxy_type,implementations:a.implementations};save('RESULTAT.json',report);console.log(JSON.stringify(report,null,2));
})().catch(e=>{console.error(e);process.exitCode=1});
